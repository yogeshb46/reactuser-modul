import React from 'react';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";
import Signin from '../Auth/Signin';
import Signup from '../Auth/Signup';
import Dashboard from '../Screens/Dashboard';


class Layouts extends React.Component{

    render(){
        return(<>
        <Router>
        <div>
            <nav>
            <ul>
                <li>
                <Link to="/">Sign In</Link>
                </li>
                <li>
                <Link to="/signup">Sign UP</Link>
                </li>
                <li>
                <Link to="/dashboard">dashboard</Link>
                </li>
            </ul>
            </nav>

        {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
        <Switch>
            <Route exact path="/" component={Signin} />
            <Route path="/signup" component={Signup} />
            <Route exact path="/dashboard" component={Dashboard} />
        </Switch>
      </div>
    </Router>
        </>);
    }
}
export default Layouts;