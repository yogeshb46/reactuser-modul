import React from 'react';
import { Table, Container,Col,Row } from 'react-bootstrap';
import axios from 'axios';


class Dashboard extends React.Component{
   
    constructor(props){
        super(props);
        this.state = {
            userdata :[]
        }
    }

    componentDidMount(){
        axios.get('https://reqres.in/api/users/').then(res => {
        
         this.setState({
            userdata :res.data.data
         });
        })
        .catch((error) => {
          console.log(error);
        })
    }

    render(){
        return(<>
        
        <h1> Dashboard </h1>
        <Container>
            <Row>
                <Col md="12">
                   
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                            <th>#</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Username</th>
                            </tr>
                        </thead>
                      
                        {this.state.userdata ? (
                            this.state.userdata.map((data1)=>{
                              
                             
                                    <tr>
                                    <td>{ data1.id }</td>
                                    <td>hhewui</td>
                                    <td>Otto</td>
                                    <td>@mdo</td>
                                    </tr>
                                 console.log('userduyuyu',data1.email);
                                })
                                
                        ): ('') 
                        }
                      
                    </Table>
                </Col>
            </Row>
        </Container>
        </>);
    }

}


export default Dashboard;