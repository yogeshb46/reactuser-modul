import logo from './logo.svg';
import './App.css';
import Layouts from './Layouts/Layouts';

function App() {
  return (
    <Layouts/>
  );
}

export default App;
