import React from 'react';
import { Button,Form,Container,Col,Row } from 'react-bootstrap';
import history from '../history/history';

class Signin extends React.Component{

    constructor(props){
        super(props);
        this.state = {
               userName : "",
               password : "",
        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentDidMount(){
        this.userList = JSON.parse(localStorage.getItem('user1'));
        console.log('SingInUser',this.userList)
        // axios.get('https://reqres.in/api/users?page=2')
        // .then(res => {
        //  console.log('Rsdd',res);
        // })
        // .catch((error) => {
        //   console.log(error);
        // })
    }
 
    
    handleChange(event) {
        const name = event.target.name;
        const value = event.target.value;
    
        this.setState({ 
            [name]: value
        })
    }

     
    handleSubmit=(event)=> {
        event.preventDefault();
        
        this.userList.map((user)=>{
            console.log('usernameloca',user.userName);
            console.log('username',this.state.userName);
             if (user.userName === this.state.userName || user.email === this.state.userName && user.password === this.state.password){
                 history.push("/dashboard");
             } else {
                 console.log('Sorry')
             }
        })
        // localStorage.setItem('user1',JSON.stringify(this.userData));
        // this.getValue();
        // console.log('this.value',this.getValue());
    }




    render(){
        return(<>Sign IN
        <Container>
            <Row>
                <Col md="12">
                <Form onSubmit={this.handleSubmit}>
                  
                        <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label>User Name</Form.Label>
                            <Form.Control type="text" name ="userName" value = {this.state.userName} onChange={this.handleChange} placeholder="Please Enter Your User Name" />
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicPassword">
                            <Form.Label>Password</Form.Label>
                            <Form.Control type="password" name = "password" value = {this.state.password} onChange={this.handleChange} placeholder="Password" />
                        </Form.Group>

                        <Button variant="primary" type="submit">
                            Submit
                        </Button>
                        </Form>
                </Col>
            </Row>
        </Container>
        </>);
    }
}
export default Signin;